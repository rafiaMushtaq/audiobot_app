package com.justai.aimybox.assistant;

class User {
    String nickname;
    String profileUrl;
}