package com.justai.aimybox.components

import com.justai.aimybox.logging.Logger

val L = Logger("Aimybox-Components")