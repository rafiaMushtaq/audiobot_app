## happy path
* greet
  - utter_greet
* mood_great
  - utter_happy

## sad path 1
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* affirm
  - utter_happy

## sad path 2
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* getNews
    - get_news
    - form{"name": "get_news"}
    - slot{"requested_slot": "topic_news"}



* weatherInformation
    - weather_information_form
  - form{"name": "weather_information_form"}
  - form{"name": null}

* informRestaurant
  - restaurant_form
  -  form{"name": "restaurant_form"}
  -  slot{"requested_slot": "hotel_info"}

* deny
  - utter_goodbye

## interactive_story_news

* greet
    -utter_greet

* getNews{"topic_news": "cricket"}
    - slot{"topic_news": "cricket"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "pakistan cricket match"}
    - slot{"topic_news": "pakistan cricket match"}
    - form{"name": null}
    - slot{"requested_slot": null}

* getNews{"topic_news": "foot ball match"}
    - slot{"topic_news": "foot ball match"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "pakistan foot ball match match"}
    - slot{"topic_news": "pakistan football match match"}
    - form{"name": null}
    - slot{"requested_slot": null}
* deny
  - utter_goodbye


## interactive_story_another

* greet
    -utter_greet

* getNews{"topic_news": "global warming"}
    - slot{"topic_news": "global warming"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "global warming"}
    - slot{"topic_news": "global warming"}
    - form{"name": null}
    - slot{"requested_slot": null}

* getNews{"topic_news": "global warming"}
    - slot{"topic_news": "global warming"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "global warming"}
    - slot{"topic_news": "global warming"}
    - form{"name": null}
    - slot{"requested_slot": null}
* deny
  - utter_goodbye

## interactive_story_full
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "Lahore"}
    - slot{"location": "Lahore"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "Lahore"}
    - slot{"location": "Lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "Karachi"}
    - slot{"location": "Karachi"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "Karachi"}
    - slot{"location": "Karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"GPE": "berlin", "location": "berlin"}
    - slot{"location": "berlin"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "berlin"}
    - slot{"location": "berlin"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "islamabad"}
    - slot{"location": "islamabad"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "islamabad"}
    - slot{"location": "islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "Lahore"}
    - slot{"location": "Lahore"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "Lahore"}
    - slot{"location": "Lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}

* getNews{"topic_news": "green house effect"}
    - slot{"topic_news": "green house effect"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "green house effect"}
    - slot{"topic_news": "green house effect"}
    - form{"name": null}
    - slot{"requested_slot": null}

* getNews{"topic_news": "green house effect"}
    - slot{"topic_news": "green house effect"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "green house effect"}
    - slot{"topic_news": "green house effect"}
    - form{"name": null}
    - slot{"requested_slot": null}
* deny

## interactive_story_1
* weatherInformation
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"requested_slot": "location"}
* form: weatherInformation{"location": "dammam"}
    - slot{"location": "dammam"}
    - form: weather_information_form
    - slot{"location": "dammam"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "makkah"}
    - slot{"location": "makkah"}
    - weather_information_form
* weatherInformation{"location": "medina"}
    - slot{"location": "medina"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "medina"}
    - slot{"location": "medina"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "new york"}
    - slot{"location": "new york"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "new york"}
    - slot{"location": "new york"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "london"}
    - slot{"location": "london"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "london"}
    - slot{"location": "london"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "saudi arabia"}
    - slot{"location": "saudi arabia"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "saudi arabia"}
    - slot{"location": "saudi arabia"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "london"}
    - slot{"location": "london"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "london"}
    - slot{"location": "london"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "london"}
    - form{"name": null}
    - slot{"requested_slot": null}

* goodbye
  - utter_goodbye


## interactive_story_next
* greet
  - utter_greet
* weatherInformation{"GPE": "berlin", "location": "berlin"}
    - slot{"location": "berlin"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "berlin"}
    - slot{"location": "berlin"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "rawalpindi"}
    - slot{"location": "rawalpindi"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "rawalpindi"}
    - slot{"location": "rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "canada"}
    - slot{"location": "canada"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "canada"}
    - slot{"location": "canada"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "germany"}
    - slot{"location": "germany"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "germany"}
    - slot{"location": "germany"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"GPE": "riyadh", "location": "riyadh"}
    - slot{"location": "riyadh"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "riyadh"}
    - slot{"location": "riyadh"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "amsterdam"}
    - slot{"location": "amsterdam"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "amsterdam"}
    - slot{"location": "amsterdam"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "karachi"}
    - slot{"location": "karachi"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "karachi"}
    - slot{"location": "karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "rawalpindi"}
    - slot{"location": "rawalpindi"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "rawalpindi"}
    - slot{"location": "rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "vilnius"}
    - slot{"location": "vilnius"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "vilnius"}
    - slot{"location": "vilnius"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "lahore"}
    - slot{"location": "lahore"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "lahore"}
    - slot{"location": "lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"GPE": "london", "location": "london"}
    - slot{"location": "london"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "london"}
    - slot{"location": "london"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "itlay"}
    - slot{"location": "itlay"}
    - weather_information_form
* weatherInformation{"location": "murree"}
    - slot{"location": "murree"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "murree"}
    - slot{"location": "murree"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "canada"}
    - slot{"location": "canada"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "canada"}
    - slot{"location": "canada"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "canada"}
    - form{"name": null}
    - slot{"requested_slot": null}
* goodbye
  - utter_goodbye


## say goodbye


* goodbye
  - utter_goodbye

## bot challenge
* bot_challenge
  - utter_iamabot

## interactive_story_1
* greet
    - utter_greet

## interactive_story_1
* greet
    - utter_greet
* weatherInformation{"location": "berlin"}
    - slot{"location": "berlin"}
    - weather_information_form
    - weather_information_form
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "Rawalpindi"}
    - slot{"location": "Rawalpindi"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "Rawalpindi"}
    - slot{"location": "Rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}


## interactive_story_1
* greet
    - utter_greet
* informRestaurant
  -  restaurant_form
  -  form{"name": "restaurant_form"}
  -  slot{"requested_slot": "hotel_info"}

* informRestaurant{"hotel_info": "hotels of karachi"}
    - slot{"hotel_info": "hotels of karachi"}
    - restaurant_form
* informRestaurant{"hotel_info": "thai food restaurants"}
    - slot{"hotel_info": "thai food restaurants"}
    - restaurant_form
* informRestaurant{"hotel_info": "chinese restaurant in rawalpindi"}
    - slot{"hotel_info": "chinese restaurant in rawalpindi"}
    - restaurant_form
* informRestaurant{"hotel_info": "hotels in rawalpindi"}
    - slot{"hotel_info": "hotels in rawalpindi"}
    - restaurant_form
* informRestaurant
    - restaurant_form
* informRestaurant{"hotel_info": "five star gotel in karachi"}
    - slot{"hotel_info": "five star gotel in karachi"}
    - restaurant_form


## interactive_story_1
* greet
    - utter_greet
* informRestaurant{"hotel_info": "malls in lahore"}
    - slot{"hotel_info": "malls in lahore"}
    - restaurant_form
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "malls in lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - utter_ask_hotel_info
* informRestaurant
* informRestaurant{"hotel_info": "shopping malls near my location"}
    - slot{"hotel_info": "shopping malls near my location"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls near my location"}
    - slot{"hotel_info": "shopping malls in lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls near my location"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls near my location"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "lahore places"}
    - slot{"hotel_info": "lahore places"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "lahore places"}
    - slot{"hotel_info": "lahore places"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls near my location"}
    - slot{"hotel_info": "shopping malls near my location"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls near my location"}
    - slot{"hotel_info": "shopping malls near my location"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls in islamabad"}
    - slot{"hotel_info": "shopping malls in islamabad"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in islamabad"}
    - slot{"hotel_info": "shopping malls in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "malls in karachi"}
    - slot{"hotel_info": "malls in karachi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "malls in karachi"}
    - slot{"hotel_info": "malls in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "places in lahore"}
    - slot{"hotel_info": "places in lahore"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in lahore"}
    - slot{"hotel_info": "places in lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "in karachi"}
    - slot{"hotel_info": "places in karachi"}

## interactive_story_1
* greet
    - utter_greet
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "rawalpindi"}
    - slot{"location": "rawalpindi"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "rawalpindi"}
    - slot{"location": "rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "islamabad"}
    - slot{"location": "islamabad"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "islamabad"}
    - slot{"location": "islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation{"location": "paris"}
    - slot{"location": "paris"}
    - weather_information_form
    - form{"name": "weather_information_form"}
    - slot{"location": "paris"}
    - slot{"location": "paris"}
    - form{"name": null}
    - slot{"requested_slot": null}
* weatherInformation
    - utter_ask_location
* weatherInformation
* weatherInformation
    - utter_ask_location
* weatherInformation{"location": "rawlpindi"}
    - slot{"location": "rawlpindi"}
    - weather_information_form
* informRestaurant{"hotel_info": "shopping malls near my loaction"}
    - slot{"hotel_info": "shopping malls near my loaction"}
    - restaurant_form
* informRestaurant{"hotel_info": "shopping malls in islamabad"}
    - slot{"hotel_info": "shopping malls in islamabad"}
    - restaurant_form
    - action_restaurant
* informRestaurant
    - utter_ask_hotel_info
* informRestaurant{"hotel_info": "shopping malls in karachi"}
    - slot{"hotel_info": "shopping malls in karachi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in karachi"}
    - slot{"hotel_info": "shopping malls in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls near my location"}
    - slot{"hotel_info": "shopping malls near my location"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls near my location"}
    - slot{"hotel_info": "shopping malls near my location"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls"}
    - slot{"hotel_info": "shopping malls"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls"}
    - slot{"hotel_info": "shopping malls"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls in delhi"}
    - slot{"hotel_info": "shopping malls in delhi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in delhi"}
    - slot{"hotel_info": "shopping malls in delhi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - action_restaurant
* informRestaurant
* informRestaurant
* informRestaurant{"hotel_info": "shopping malls in karachi"}
    - slot{"hotel_info": "shopping malls in karachi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in karachi"}
    - slot{"hotel_info": "shopping malls in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls in paris"}
    - slot{"hotel_info": "shopping malls in paris"}
    - restaurant_form
* informRestaurant{"hotel_info": "shopping malls"}
    - slot{"hotel_info": "shopping malls"}
    - restaurant_form
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls in paris"}
    - slot{"hotel_info": "shopping malls in paris"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in paris"}
    - slot{"hotel_info": "shopping malls in paris"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"location": "paris", "hotel_info": "shopping malls in paris"}
    - slot{"hotel_info": "shopping malls in paris"}
    - slot{"location": "paris"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in paris"}
    - slot{"hotel_info": "shopping malls in paris"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "lahore defence malls"}
    - slot{"hotel_info": "lahore defence malls"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "lahore defence malls"}
    - slot{"hotel_info": "lahore defence malls"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "lahore defence malls"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"location": "newphew", "hotel_info": "malls in karachi"}
    - slot{"hotel_info": "malls in karachi"}
    - slot{"location": "newphew"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "malls in karachi"}
    - slot{"hotel_info": "malls in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "malls in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "malls in rawalpindi"}
    - slot{"hotel_info": "parks in lahore"}

* informRestaurant{"hotel_info": "shopping malls in paris"}
    - slot{"hotel_info": "places in lahore"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in karachi"}
    - slot{"hotel_info": "shopping malls in paris"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"location": "paris", "hotel_info": "places"}
    - slot{"hotel_info": "honeymoon places"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in karachi"}
    - slot{"hotel_info": "beach"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "honey moon places"}
    - slot{"hotel_info": "beach"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in dubai"}
    - slot{"hotel_info": "places in saudi arabia"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in dubai"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - slot{"hotel_info": "malls in rawalpindi"}
    - slot{"location": "newphew"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "beach"}
    - slot{"hotel_info": "parks in new york"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in canada"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "parks in karachi"}
    - slot{"hotel_info": "picnic places in karachi"}



* informRestaurant{"hotel_info": "shopping malls in islamabad"}
    - slot{"hotel_info": "places in lahore"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in islamabad"}
    - slot{"hotel_info": "shopping malls in paris"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"location": "paris", "hotel_info": "places"}
    - slot{"hotel_info": "honeymoon places"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in lahore"}
    - slot{"hotel_info": "beach"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "honey moon places"}
    - slot{"hotel_info": "beach"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in dubai"}
    - slot{"hotel_info": "places in saudi arabia"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in saudi arabia"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - slot{"hotel_info": "malls in paris"}
    - slot{"location": "newphew"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "beach"}
    - slot{"hotel_info": "lahore malls"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in canada"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "parks in lahore"}
    - slot{"hotel_info": "picnic places in karachi"}

## interactive_story_1
* informRestaurant{"hotel_info": "parks in karachi"}
    - slot{"hotel_info": "parks in karachi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in karachi"}
    - slot{"hotel_info": "parks in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "parks in canada"}
    - slot{"hotel_info": "parks in canada"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in canada"}
    - slot{"hotel_info": "parks in canada"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls"}
    - slot{"hotel_info": "shopping malls"}
* informRestaurant{"hotel_info": "shopping places"}
    - slot{"hotel_info": "shopping places"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping places"}
    - slot{"hotel_info": "shopping places"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "food restaurants"}
    - slot{"hotel_info": "food restaurants"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "food restaurants"}
    - slot{"hotel_info": "food restaurants"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "food in pakistan"}
    - slot{"hotel_info": "food in pakistan"}
* informRestaurant{"hotel_info": "it"}
    - slot{"hotel_info": "it"}
    - restaurant_form
* informRestaurant{"hotel_info": "restaurants in lahore"}
    - slot{"hotel_info": "restaurants in lahore"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "restaurants in lahore"}
    - slot{"hotel_info": "restaurants in lahore"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "restaurants in karachi"}
    - slot{"hotel_info": "restaurants in karachi"}
* informRestaurant{"hotel_info": "restaurants in karachi"}
    - slot{"hotel_info": "restaurants in karachi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "restaurants in karachi"}
    - slot{"hotel_info": "restaurants in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
* informRestaurant{"hotel_info": "famous restaurants in mumbai"}
    - slot{"hotel_info": "famous restaurants in mumbai"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "famous restaurants in mumbai"}
    - slot{"hotel_info": "famous restaurants in mumbai"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "food in malaysia"}
    - slot{"hotel_info": "food in malaysia"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "food in malaysia"}
    - slot{"hotel_info": "food in malaysia"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "turkey dinner places"}
    - slot{"hotel_info": "turkey dinner places"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "turkey dinner places"}
    - slot{"hotel_info": "turkey dinner places"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
* informRestaurant{"hotel_info": "afghani food"}
    - slot{"hotel_info": "afghani food"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "afghani food"}
    - slot{"hotel_info": "afghani food"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "chinese food"}
    - slot{"hotel_info": "chinese food"}


* informRestaurant{"hotel_info": "restaurants in lahore"}
    - slot{"hotel_info": "restaurants in rawalpindi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in paris"}
    - slot{"hotel_info": "restaurants in karachi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "hotels in rawalpindi"}
    - slot{"hotel_info": "hotels near my location"}
* informRestaurant{"hotel_info": "restaurants in attock"}
    - slot{"hotel_info": "restaurants in pris"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "Chinese restaurant"}
    - slot{"hotel_info": "desi food restaurants"}
    - form{"name": null}
    - slot{"requested_slot": null}
     - restaurant_form
* informRestaurant
* informRestaurant{"hotel_info": "famous restaurants in mumbai"}
    - slot{"hotel_info": "famous restaurants in mumbai"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "famous restaurants in mumbai"}
    - slot{"hotel_info": "famous restaurants in mumbai"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "food in malaysia"}
    - slot{"hotel_info": "food in malaysia"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "food in malaysia"}
    - slot{"hotel_info": "food in malaysia"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "turkey dinner places"}
    - slot{"hotel_info": "turkey dinner places"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "restaurants near my location"}
    - slot{"hotel_info": "restaurants near my location"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
* informRestaurant{"hotel_info": "afghani food"}
    - slot{"hotel_info": "afghani food"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "afghani food"}
    - slot{"hotel_info": "afghani food"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "asian oriental"}
    - slot{"hotel_info": "asian oriental"}
    - restaurant_form


## interactive_story_1
* greet
    - utter_greet
* getNews{"topic_news": "corona virus"}
    - slot{"topic_news": "corona virus"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "corona virus"}
    - slot{"topic_news": "corona virus"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "date of covid-19"}
    - slot{"topic_news": "date of covid-19"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "date of covid-19"}
    - slot{"topic_news": "date of covid-19"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
    - utter_ask_topic_news
* getNews{"topic_news": "dates of world cup"}
    - slot{"topic_news": "dates of world cup"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "dates of world cup"}
    - slot{"topic_news": "dates of world cup"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "famous food in china"}
    - slot{"hotel_info": "famous food in china"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "famous food in china"}
    - slot{"hotel_info": "famous food in china"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "president of israel"}
    - slot{"topic_news": "president of israel"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "president of israel"}
    - slot{"topic_news": "president of israel"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "largest city of pakistan"}
    - slot{"hotel_info": "largest city of pakistan"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "largest city of pakistan"}
    - slot{"hotel_info": "largest city of pakistan"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "states in azad kashmir"}
    - slot{"hotel_info": "states in azad kashmir"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "states in azad kashmir"}
    - slot{"hotel_info": "states in azad kashmir"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
* getNews
* getNews{"topic_news": "founder of pakistan"}
    - slot{"topic_news": "founder of pakistan"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "states in azad kashmir"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "founder of pakistan"}
    - slot{"topic_news": "founder of pakistan"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "founder of pakistan"}
    - slot{"topic_news": "founder of pakistan"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "shopping malls in new york"}
    - slot{"topic_news": "shopping malls in new york"}
* informRestaurant{"hotel_info": "shopping malls in new york"}
    - slot{"hotel_info": "shopping malls in new york"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in new york"}
    - slot{"hotel_info": "shopping malls in new york"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
* getNews
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "shopping malls in new york"}
    - form{"name": null}
    - slot{"requested_slot": null}
* goodbye
    - utter_goodbye
* weatherInformation

## interactive_story_1
* getNews
    - utter_ask_topic_news
* getNews
* getNews{"topic_news": "china came into being"}
    - slot{"topic_news": "china came into being"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "china came into being"}
    - slot{"topic_news": "china came into being"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
* getNews{"topic_news": "dengue fever"}
    - slot{"topic_news": "dengue fever"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "dengue fever"}
    - slot{"topic_news": "dengue fever"}
    - form{"name": null}
    - slot{"requested_slot": null}
* affirm
    - utter_happy
* getNews
* getNews
* getNews
* deny
    - utter_goodbye
* getNews
* getNews
- form{"name": "get_news"}
    - slot{"topic_news": "english language"}
    - slot{"topic_news": "day of prosecution"}
    - form{"name": null}
    - slot{"requested_slot": null}
 - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "english language"}
    - slot{"topic_news": "day of prosecution"}
    - form{"name": null}
    - slot{"requested_slot": null}
* affirm

## interactive_story_1
* getNews{"topic_news": "sports"}
    - slot{"topic_news": "sports"}
    - get_news
* getNews
    - utter_ask_topic_news
* getNews{"topic_news": "physics"}
    - slot{"topic_news": "physics"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "physics"}
    - slot{"topic_news": "physics"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "sports"}
    - slot{"topic_news": "sports"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "sports"}
    - slot{"topic_news": "sports"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "news of india"}
    - slot{"topic_news": "news of india"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "news of india"}
    - slot{"topic_news": "news of india"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "news of india"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
    - utter_ask_topic_news
* getNews
* getNews
* getNews
* getNews{"topic_news": "machine learning"}
    - slot{"topic_news": "machine learning"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "machine learning"}
    - slot{"topic_news": "machine learning"}
 
* getNews
    - utter_ask_topic_news  
* getNews
    - utter_ask_topic_news
* getNews{"topic_news": "buisness"}
    - slot{"topic_news": "buisness"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "economic of PAKIStan "}
    - slot{"topic_news": "economic of pakistan"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "news of pakistan"}
    - slot{"topic_news": "pakistan news"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "fashion"}
    - slot{"topic_news": "fashion"}

* getNews{"topic_news": "pakistan latest news"}
    - slot{"topic_news": "latest news of pakistan"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "buisnesses in pakistan"}
    - slot{"topic_news": "buisness in pakistan"}


    * getNews{"topic_news": "pakistan president"}
    - slot{"topic_news": "pakistan president"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "prime minister of pakistan"}
    - slot{"topic_news": "pakistan army"}


    * getNews{"topic_news": "physics news"}
    - slot{"topic_news": "physics news"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "corona virus"}
    - slot{"topic_news": "covid-19"}

* getNews{"topic_news": "psl dates"}
    - slot{"topic_news": "psl dates"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "dates of psl"}
    - slot{"topic_news": "dates of psl"}
  

    * getNews{"topic_news": "pakistan cricket news"}
    - slot{"topic_news": "pakistan cricket news"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "cricket of pakistan"}
    - slot{"topic_news": "cricket of pakistan"}

## interactive_story_1
* greet
    - utter_greet
* getNews
    - utter_ask_topic_news
* getNews{"news_info": "psl date"}
* getNews
* getNews{"topic_news": "psl match dates"}
    - slot{"topic_news": "psl match dates"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "psl match dates"}
    - slot{"topic_news": "psl match dates"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "buisness"}
    - slot{"topic_news": "buisness"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "buisness"}
    - slot{"topic_news": "buisness"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
    - utter_ask_topic_news
* getNews
    - utter_ask_topic_news
* getNews
* getNews
* getNews
* getNews
* getNews
    - utter_ask_topic_news
* getNews{"topic_news": "china economics"}
    - slot{"topic_news": "china economics"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "china economics"}
    - slot{"topic_news": "china economics"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "china economics"}
    - slot{"topic_news": "china economics"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "china economics"}
    - slot{"topic_news": "china economics"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "technology"}
    - slot{"topic_news": "technology"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "technology"}
    - slot{"topic_news": "technology"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "fashion"}
    - slot{"topic_news": "fashion"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "fashion"}
    - slot{"topic_news": "fashion"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
    - utter_ask_topic_news
* getNews{"topic_news": "pakistan cricket"}
    - slot{"topic_news": "cricket match"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "football match"}
    - slot{"topic_news": "footal match"}

* getNews{"topic_news": "pakistan football"}
    - slot{"topic_news": "pakistan football"}
    - get_news
    - form{"name": "get_news"}
    - form{"name": "football match"}
    - slot{"requested_slot": "pakistan football match"}
## interactive_story_1
* getNews
    - utter_ask_topic_news
* getNews
* getNews
* getNews
* getNews{"topic_news": "president of america"}
    - slot{"topic_news": "president of america"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "president of america"}
    - slot{"topic_news": "president of america"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "president of china"}
    - slot{"topic_news": "president of china"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "president of china"}
    - slot{"topic_news": "president of china"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "president of india"}
    - slot{"topic_news": "president of india"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "president of india"}
    - slot{"topic_news": "president of india"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
    - utter_ask_topic_news
* getNews
    - utter_ask_topic_news
* getNews
* getNews{"topic_news": "technology"}
    - slot{"topic_news": "technology"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "technology"}
    - slot{"topic_news": "technology"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"news_info": "psl match date"}
* getNews
    - utter_ask_topic_news
* getNews
    - utter_ask_topic_news
* getNews
* getNews
* getNews{"topic_news": "physics"}
    - slot{"topic_news": "physics"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "physics"}
    - slot{"topic_news": "physics"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
* getNews{"topic_news": "cricket"}
    - slot{"topic_news": "cricket"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "pakistan cricket match"}
    - slot{"topic_news": "pakistan cricket match"}
    - form{"name": null}
    - slot{"requested_slot": null}

* getNews
* getNews{"topic_news": "cricket"}
    - slot{"topic_news": "cricket"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "cricket match"}
    - slot{"topic_news": "cricket match"}
    - form{"name": null}
    - slot{"requested_slot": null}

* getNews
* getNews{"topic_news": "football"}
    - slot{"topic_news": "football"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "pakistan football match"}
    - slot{"topic_news": "pakistan football match"}
    - form{"name": null}
    - slot{"requested_slot": null}
## interactive_story_1
    - slot{"topic_news": "psl matches"}
    - slot{"topic_news": "psl matches"}
    - slot{"topic_news": "psl matches"}
    - slot{"requested_slot": null}
    - slot{"topic_news": "cricket match"}
    - slot{"topic_news": "cricket match"}
    - slot{"topic_news": "cricket match"}
    - slot{"requested_slot": null}
    - slot{"topic_news": "foot ball match"}
    - slot{"requested_slot": "hotel_info"}
    - slot{"topic_news": "foot ball match"}
    - slot{"requested_slot": null}
    - slot{"topic_news": "foot ball match"}
    - slot{"topic_news": "foot ball match"}
    - slot{"topic_news": "foot ball match"}
    - slot{"requested_slot": null}
    - slot{"topic_news": "foot ball match"}
* getNews
    - utter_ask_topic_news
* getNews{"topic_news": "psl match"}
    - slot{"topic_news": "psl match"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "psl match"}
    - slot{"topic_news": "psl match"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "hotels in paris"}
    - slot{"hotel_info": "hotels in paris"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "hotels in paris"}
    - slot{"hotel_info": "hotels in paris"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
* getNews
* getNews
    - utter_ask_topic_news
* getNews
* informRestaurant{"hotel_info": "fast food"}
    - slot{"hotel_info": "fast food"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "fast food"}
    - slot{"hotel_info": "fast food"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "day of prosecution"}
    - slot{"topic_news": "day of prosecution"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "day of prosecution"}
    - slot{"topic_news": "day of prosecution"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "pakistan came into being"}
    - slot{"topic_news": "pakistan came into being"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "pakistan came into being"}
    - slot{"topic_news": "pakistan came into being"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews{"topic_news": "pakistan came into being"}
    - slot{"topic_news": "pakistan came into being"}
    - get_news
    - form{"name": "get_news"}
    - slot{"topic_news": "pakistan came into being"}
    - slot{"topic_news": "pakistan came into being"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls in turkey"}
    - slot{"hotel_info": "shopping malls in turkey"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls in turkey"}
    - slot{"hotel_info": "shopping malls in turkey"}
    - form{"name": null}
    - slot{"requested_slot": null}
* getNews
* informRestaurant{"hotel_info": "islamabad markets"}
    - slot{"hotel_info": "islamabad markets"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "islamabad markets"}
    - slot{"hotel_info": "islamabad markets"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "picnic points in islambad"}
    - slot{"hotel_info": "picnic points in islambad"}
    - restaurant_form
* informRestaurant{"hotel_info": "parks in rawalpindi"}
    - slot{"hotel_info": "parks in rawalpindi"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in rawalpindi"}
    - slot{"hotel_info": "parks in rawalpindi"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
* informRestaurant{"hotel_info": "parks in islamabad"}
    - slot{"hotel_info": "parks in islamabad"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in islamabad"}
    - slot{"hotel_info": "parks in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "parks in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "islamabad markets"}
    - slot{"hotel_info": "islamabad markets"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "islamabad markets"}
    - slot{"hotel_info": "islamabad markets"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "islamabad markets"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"requested_slot": "hotel_info"}
* form: informRestaurant{"hotel_info": "hotel in lahore"}
    - slot{"hotel_info": "hotels in lahore"}

* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "shopping malls"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant{"hotel_info": "shopping malls"}
    - slot{"hotel_info": "shopping malls"}
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "islamabad places"}
    - slot{"hotel_info": "islamabad places"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"hotel_info": "places in islamabad"}
    - form{"name": null}
    - slot{"requested_slot": null}
* informRestaurant
    - restaurant_form
    - form{"name": "restaurant_form"}
    - slot{"requested_slot": "hotel_info"}
* form: informRestaurant{"hotel_info": "hotel in karachi"}
    - slot{"hotel_info": "hotels in lahore"}

