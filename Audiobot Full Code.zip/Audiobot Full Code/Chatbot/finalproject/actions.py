# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/core/actions/#custom-actions/



from rasa_sdk import Action, Tracker
from rasa_sdk import ActionExecutionRejection
from rasa_sdk import Tracker
from rasa_sdk.events import SlotSet, FollowupAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormAction, REQUESTED_SLOT, Action
from rasa.core.slots import Slot
from typing import Dict, Text, Any, List, Union
from google import google

import sqlite3
import requests
#%%

##############################################################################################################
# Global Constants

NEWS_API_KEY = '2c12b8b0c20843a1996824f20500b3c8'  

##############################################################################################################

#%%

# A form action to fetch news from the internet

class weatherInformationForm(FormAction):
    def name(self) -> Text:
        """Unique identifier of the form"""

        return "weather_information_form"

    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        """A list of required slots that the form has to fill"""

        return ["location"]

    def submit(
            self,
            dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Define what the form has to do
            after all required slots are filled"""

        # utter submit template
        api_address='http://api.openweathermap.org/data/2.5/weather?appid=d98a9aede73d2bfa92fd53cabc6a3497&q='
        city = tracker.get_slot('location')
        url = api_address + city
        json_data = requests.get(url).json()
        format_add = json_data['weather'][0]['description']
        temp = json_data['main']['temp']
        temp_min = json_data['main']['feels_like']
        temp_max = json_data['main']['temp_max']
        temp_pree = json_data['main']['pressure']
        temp_hum = json_data['main']['humidity']
        vis=json_data['wind']
        cun=json_data['sys']['country']

        response = """It is currently {} in {} at the moment. The temperature is {} farenhite, the humidity is {} and the wind speed is {} mph.""".format(format_add, city, temp, temp_hum,temp_pree)        

         
        dispatcher.utter_message(response)
    
        dispatcher.utter_message(text="The country of this city is")
        dispatcher.utter_message(cun)
 
        return []
    def slot_mappings(self) -> Dict[Text, Union[Dict, List[Dict]]]:
        """A dictionary to map required slots to
            - an extracted entity
            - intent: value pairs
            - a whole message
            or a list of them, where a first match will be picked"""

        return {
            "location": [self.from_entity(entity="location", intent='weatherInformation'),
                     self.from_text()],
            
        }

class getNews(FormAction):
    def name(self):
        return "get_news"
    
    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        """A list of required slots that the form has to fill"""

        return ["topic_news"]

    def slot_mappings(self):
        return {"topic_news": [self.from_text(intent=[None, "getNews", "inform"]), 
                               self.from_entity(entity="topic_news", intent =["getNews"])]}

    def validate(self,
                 dispatcher: CollectingDispatcher,
                 tracker: Tracker,
                 domain: Dict[Text, Any]) -> List[Dict]:

        slot_values = self.extract_other_slots(dispatcher, tracker, domain)
        
        # extract requested slot
        slot_to_fill = tracker.get_slot(REQUESTED_SLOT)
        if slot_to_fill:
            slot_values.update(self.extract_requested_slot(dispatcher, tracker, domain))
            if not slot_values:
                # reject form action execution
                # if some slot was requested but nothing was extracted
                # it will allow other policies to predict another action
                raise ActionExecutionRejection(self.name(),
                                               "Failed to validate slot {0} "
                                               "with action {1}"
                                               "".format(slot_to_fill,
                                                         self.name()))

        return [SlotSet(slot, value) for slot, value in slot_values.items()]

    def submit(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict]:

        """Define what the form has to do
            after all required slots are filled"""

        topic_news = tracker.get_slot("topic_news")

        num_page = 1
       
        search_results = google.search(topic_news, num_page)
        for result in search_results:
            dispatcher.utter_message(result.description)

        dispatcher.utter_template("utter_confirm_if_service_is_correct", tracker)

        # utter submit template
        return []
        
class ActionRestaurant(Action):
    def name(self):
        return 'action_restaurant'

    def run(self, dispatcher: CollectingDispatcher,
             tracker: Tracker,
             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:



         api_key = 'AIzaSyBNmsq9B3L_bapRaBQc-qt5TDpXknB3-uw'
         url = "https://maps.googleapis.com/maps/api/place/textsearch/json?"
         query = tracker.get_slot('hotel_info')
         r = requests.get(url + 'query=' + query +
                        '&key=' + api_key) 
         x = r.json() 
         y = x['results']
         for i in range(len(y)):
            response=y[i]['name']  
            dispatcher.utter_message(response)
         return

class RestaurantForm(FormAction):
    def name(self) -> Text:
        """Unique identifier of the form"""

        return "restaurant_form"

    @staticmethod
    def required_slots(tracker: Tracker) -> List[Text]:
        """A list of required slots that the form has to fill"""

        return ["hotel_info"]

    def submit(
            self,
            dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any],
    ) -> List[Dict]:
        """Define what the form has to do
            after all required slots are filled"""

        # utter submit template
        api_key = 'AIzaSyBNmsq9B3L_bapRaBQc-qt5TDpXknB3-uw'
        url = "https://maps.googleapis.com/maps/api/place/textsearch/json?"
        query = tracker.get_slot('hotel_info')
        r = requests.get(url + 'query=' + query +
                        '&key=' + api_key) 
        x = r.json() 
        y = x['results']
        for i in range(len(y)):
            response=y[i]['name']  
            dispatcher.utter_message(response)
          
        
 
        return []
    def slot_mappings(self) -> Dict[Text, Union[Dict, List[Dict]]]:
        """A dictionary to map required slots to
            - an extracted entity
            - intent: value pairs
            - a whole message
            or a list of them, where a first match will be picked"""

        return {
            "hotel_info": [self.from_entity(entity="hotel_info", intent='informRestaurant'),
                     self.from_text()],
            
        }

